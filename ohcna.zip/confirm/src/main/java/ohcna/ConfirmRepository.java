package ohcna;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface ConfirmRepository extends PagingAndSortingRepository<Confirm, Long>{


}